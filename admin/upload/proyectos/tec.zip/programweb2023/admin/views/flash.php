<div class="alert alert-<?php echo $color; ?>" role="alert">
  <?php echo $mensaje; ?>
</div>